import java.util.Scanner;

class IpDemo{
	public static void main(String args[]){ 
	
	Scanner sc = new Scanner(System.in);
	


	//int a = sc.nextInt();

	//float f = sc.nextFloat();
	
	//String s = sc.next();
	//String s = sc.nextLine();
	
	char s = sc.next().charAt(5);



/*
nextLong()
nextDouble()
nextByte()
nextShort()

next()
nextLine()
*/	

	//System.out.println("Value of a is : " + a);
	//System.out.println("Value of f is : " + f);
	System.out.println("Value of s is : " + s);


	}
}
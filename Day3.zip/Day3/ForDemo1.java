class ForDemo1{
	public static void main(String args[]){


	/*
	for(int a=10; a>=5; a--){
		System.out.println(a);
	}*/


	/*for(int a=10; a>=5; ){
		System.out.println(a);
	}*/

	/*for(int a=10; a>=5; a++){
		System.out.println(a);
	}*/


	/*int a=10;
	for(; a>=5; System.out.println("helllooooo")){
		System.out.println(a);
		a--;
	}*/

	/*for(; ; ){
		System.out.println(10);
	}*/
	

	System.out.println("ABC");
	

	

	}

}

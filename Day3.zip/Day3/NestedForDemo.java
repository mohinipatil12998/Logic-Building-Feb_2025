class NestedForDemo{
	public static void main(String args[]){ 
	
	/*for(int a=10; a>=5; a--){
		for(int b=10; b>=5; b--){
			System.out.println(a);
		}
	}*/

	/*
	for(int a=10; a>=5; a--){
		for(int b=10; b>=5; b--){
			System.out.print(b+" ");
		}
	System.out.println();

	}*/

	/*for(int i =0; i<5 ; i++){
		for(int j =0; j<5 ; j++){
			System.out.print(j+" ");
		} 
	System.out.println();	
	}*/ 

	














	/*for(int i =0; i<5 ; i++){
		for(int j =0; j<=i ; j++){
			System.out.print(j+" ");
		} 
	System.out.println();	
	} */

	/*for(int i =0; i<5 ; i++){
		for(int j =0; j<=i ; j++){
			System.out.print("*");
		} 
	System.out.println();	
	} */

	/*
	int count=0;
	for(int i =0; i<5 ; i++){
		for(int j =0; j<=i ; j++){
			System.out.print(++count +" ");
		} 
	System.out.println();	
	}
	*/




/*
1
2 3
4 5 6
7 8 9 10

A
B C 
D E F
G H I J
*/























	/*int a =10;
	while(a>=5){
		
		int b=10;
		while(b>=5){
			System.out.println(a);
			b--;
			}

		a--;	
	}*/


		
	} 

}













/*

a 	b               sop
10	10		10	
	9		10
	8		10
	7		10
	6		10
	5		10
	4		-----
9	10		9
	9		9
	8		9
	7		9
	6		9
	5		9
	4		-----
8 	10		8
	9		8
	8		8
	7		8
	6		8
	5		8
	4		-----

*/









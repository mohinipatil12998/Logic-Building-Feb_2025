class DoWhileDemo{
	public static void main(String args[]){ 

	/*do{
		System.out.println(" DoWhileDemo ");
	}while(true);
	*/

	/*do{
		System.out.println(" DoWhileDemo ");
	}while(false);
	*/

	/*
	do{
		System.out.println(" DoWhileDemo ");
	}while(true);
	System.out.println(10);
	*/

	/*do{
		System.out.println(" DoWhileDemo ");
	}while(false);
	System.out.println(10);
	*/
	
	/*int a = 10;
	do{
		System.out.println(a);
		a++;
	}while(a>=5);
	System.out.println(10);*/

	}

}


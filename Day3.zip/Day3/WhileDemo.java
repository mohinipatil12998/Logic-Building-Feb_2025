class WhileDemo{
	public static void main(String args[]){

	int a = 10;
	/*while(a>=5){
		System.out.println(a);
		//a = a-1;
		a--;
	}*/

	/*while(false){
		System.out.println(a);
		//a = a-1;
		a--;
	}*/
	/*while(true){
		System.out.println(a);
		//a = a-1;
		a--;
	}*/


	//System.out.println("Outside While");

	 }

}


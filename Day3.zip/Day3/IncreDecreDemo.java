class IncreDecreDemo{
	public static void main(String args[]){ 

	int a=10; // 11,,,,12

	/*System.out.println(a);   // 10
	System.out.println(++a); // 11 pre-incre
	System.out.println(a++); // 11 post-incre - 12
	System.out.println(--a); // 11 pre-decre 
	System.out.println(a--); // 11  post-decre - 10
	System.out.println(a);	 // 10	
	*/
	int b = 20; //21,,,,20,,,,,,
	int c = b++ + --b + a++ - a++; // 39,38,40,60
		20+20+10-11


	System.out.println(c);

	}


}


/*
increment and decrement Operator

2 type - Post & Pre
*/
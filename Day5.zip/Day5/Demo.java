class Demo1{ 
static{System.out.println("static block of Demo class");}

}
class Demo{

	//static{System.out.println("static block of Demo class");}
	public static void main(String args[]){ 

	}
}